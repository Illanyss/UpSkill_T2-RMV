/*package pt.upskills.projeto.objects;

import pt.upskills.projeto.game.Engine;
import pt.upskills.projeto.gui.FireTile;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Position;

public class FireBall implements FireTile {
    private Position position;

    public FireBall(Position position) {
        this.position = position;
    }

    public setPosition(){
        this.position = position;
    }

    @Override
    public boolean validateImpact() {
        for(ImageTile tile : Engine.tiles){
            if(tile instanceof Wall) {
                if(tile.getPosition() etc...){

                }
                return false;
            }
        }
        return true;
    }
}*/
