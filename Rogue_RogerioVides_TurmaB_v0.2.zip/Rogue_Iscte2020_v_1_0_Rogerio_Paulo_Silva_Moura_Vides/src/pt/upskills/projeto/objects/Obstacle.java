package pt.upskills.projeto.objects;

public abstract class Obstacle {

}

