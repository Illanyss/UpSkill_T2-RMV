package pt.upskills.projeto.objects;

import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Position;

public abstract class Enemy implements ImageTile {
    private Position position;
    private int hp;

    public Enemy(Position position, int hp) {
        this.position = position;
        this.hp = hp;
    }

    public int getHP(){
        return hp;
    }

    @Override
    public String getName() {
        return "Enemy";
    }

    @Override
    public Position getPosition() {
        return position;
    }

    public void moving(){
    }

    public void damage(int hp){
        this.hp -= hp;
        System.out.println("Enemy HP: "+this.hp);
    }
}
