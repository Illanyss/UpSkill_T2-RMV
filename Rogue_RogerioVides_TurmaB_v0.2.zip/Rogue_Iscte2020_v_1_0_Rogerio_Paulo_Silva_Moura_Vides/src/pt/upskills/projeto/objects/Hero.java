package pt.upskills.projeto.objects;

import pt.upskills.projeto.game.Engine;
import pt.upskills.projeto.gui.ImageMatrixGUI;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Direction;
import pt.upskills.projeto.rogue.utils.Position;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class Hero implements ImageTile, Observer {

    private Position position;
    private int MoveScore;
    private int HP = 8;
    //private List<ImageTile> statusTiles = new ArrayList();
    //private List<ImageTile> tiles = new ArrayList<>(Engine.tiles);
    private List<ImageTile> inventory = new ArrayList<>(3);
    //private String item;

    public Hero(Position position) {
        this.position = position;
    }

    public void damage(int HP){
        this.HP -= HP;
        System.out.println("Enemy HP: "+this.HP);
    }

    public void pickUpItem(){
        List<ImageTile> tiles = new ArrayList<>(Engine.tiles);
        List<ImageTile> statusTiles = new ArrayList(10);
        for (ImageTile tile : tiles) {
            if (tile instanceof Item) {
                if (position.equals(tile.getPosition())) {
                            inventory.add(tile);
                            tile.setPosition(new Position(7, 0));
                            statusTiles.add(tile);
                    
                    //inventory.add(tile);
                    Engine.gui.removeImage(tile);
                    Engine.tiles.remove(tile);
                    Engine.gui.addStatusImage(tile);
                    Engine.gui.newStatusImages(statusTiles);
                }
            }
        }
    }

    public void statusBar(){
        List<ImageTile> statusTiles = new ArrayList();
        for(int i=3;i<7; i++){
            switch (HP){
                case 0:
                    statusTiles.add(new RedTile(new Position(i, 0)));
                    break;
                case 1:
                    if(i==3) {
                        statusTiles.add(new RedGreenTile(new Position(3, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 2:
                    if(i==3) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 3:
                    if(i==3) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else if(i==4){
                        statusTiles.add(new RedGreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 4:
                    if(i<=4) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 5:
                    if(i<=4) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else if(i==5){
                        statusTiles.add(new RedGreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 6:
                    if(i<=5) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedTile(new Position(i, 0)));
                    }
                    break;
                case 7:
                    if(i<=5) {
                        statusTiles.add(new GreenTile(new Position(i, 0)));
                    } else {
                        statusTiles.add(new RedGreenTile(new Position(i, 0)));
                    }
                    break;
                case 8:
                    statusTiles.add(new GreenTile(new Position(i, 0)));
                    break;
                default:
                    statusTiles.add(new RedTile(new Position(i, 0)));
                    break;
            }
        }
        Engine.gui.newStatusImages(statusTiles);
    }

    @Override
    public String getName() {
        return "Hero";
    }

    @Override
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position heroPosition){
        this.position = heroPosition;
    }


    /**
     * This method is called whenever the observed object is changed. This function is called when an
     * interaction with the graphic component occurs {{@link ImageMatrixGUI}}
     *
     * @param o
     * @param arg
     */
    @Override
    public void update(Observable o, Object arg) {
        statusBar();
        System.out.println(MoveScore);
        System.out.println("HP: "+HP);

        Integer keyCode = (Integer) arg;
        List<ImageTile> tiles = new ArrayList<>(Engine.tiles);
        for (ImageTile tile : tiles) {
            if (tile instanceof Enemy) {
                ((Enemy) tile).moving();
            }
        }
        /*if (getPosition().getY() < 9 && getPosition().getY() > 0 && getPosition().getX() < 9 && getPosition().getX() > 0) {*/
            if (keyCode == KeyEvent.VK_DOWN) {
                position = position.plus(Direction.DOWN.asVector());
                MoveScore--;
                Enemy enemy = null;
                for (ImageTile tile : tiles) {
                    if (tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            enemy = ((Enemy) tile);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.UP.asVector());
                            MoveScore++;
                        }
                    }
                    if (tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            Engine.level--;
                            Engine.RoomChange();
                        }
                    }
                    pickUpItem();
                }
                if (enemy != null) {
                    enemy.damage(1);
                    if (enemy.getHP() <= 0) {
                        Engine.gui.removeImage(enemy);
                        Engine.tiles.remove(enemy);
                        Engine.gui.update();
                        System.out.println("Enemy down!!");
                    }
                }
            }
            if (keyCode == KeyEvent.VK_UP) {
                position = position.plus(Direction.UP.asVector());
                MoveScore--;
                Enemy enemy = null;
                for (ImageTile tile : tiles) {
                    if (tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            enemy = (Enemy) tile;
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.DOWN.asVector());
                            MoveScore++;
                        }
                    }
                    if (tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            Engine.level++;
                            Engine.RoomChange();
                        }
                    }
                    pickUpItem();
                }
                if (enemy != null) {
                    enemy.damage(1);
                    if (enemy.getHP() <= 0) {
                        Engine.gui.removeImage(enemy);
                        Engine.tiles.remove(enemy);
                        Engine.gui.update();
                        System.out.println("Enemy down!!");
                    }
                }
            }
            if (keyCode == KeyEvent.VK_LEFT) {
                position = position.plus(Direction.LEFT.asVector());
                MoveScore--;
                Enemy enemy = null;
                for (ImageTile tile : tiles) {
                    if (tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            enemy = (Enemy) tile;
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.RIGHT.asVector());
                            MoveScore++;
                        }
                    }
                    if (tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            Engine.level++;
                            Engine.RoomChange();
                        }
                    }
                    pickUpItem();
                }
                if (enemy != null) {
                    enemy.damage(1);
                    if (enemy.getHP() <= 0) {
                        Engine.gui.removeImage(enemy);
                        Engine.tiles.remove(enemy);
                        Engine.gui.update();
                        System.out.println("Enemy down!!");
                    }
                }
            }
            if (keyCode == KeyEvent.VK_RIGHT) {
                position = position.plus(Direction.RIGHT.asVector());
                MoveScore--;
                Enemy enemy = null;
                for (ImageTile tile : tiles) {
                    if (tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            enemy = (Enemy) tile;
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof Enemy) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.LEFT.asVector());
                            MoveScore++;
                        }
                    }
                    if (tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            Engine.level++;
                            Engine.RoomChange();
                        }
                    }
                    pickUpItem();
                }
                if (enemy != null) {
                    enemy.damage(1);
                    if (enemy.getHP() <= 0) {
                        Engine.gui.removeImage(enemy);
                        Engine.tiles.remove(enemy);
                        Engine.gui.update();
                        System.out.println("Enemy down!!");
                    }
                }
            }
        /*}*/
    }
            /*}*/
        /*if(keyCode == KeyEvent.VK_SPACE) {
            Position fireBallPosition = position.plus(lastDir.asVector());
            FireBall fireBall = new FireBall(fireBallPosition);
            FireBallThread fireBallThread = new FireBallThread(lastDir, fireBall);
            fireBallThread.start();

            Engine.tiles.add(fireBall);
            ImageMatrixGUI gui = ImageMatrixGUI.getInstance();
            gui.addImage(fireBall);
        }*/

        /*}*/


}
