package pt.upskills.projeto.objects;

import pt.upskills.projeto.game.Engine;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Direction;
import pt.upskills.projeto.rogue.utils.Position;


public class Skeleton extends Enemy implements ImageTile {

    private Position position;

    public Skeleton(Position position) {
        super(position,3);
        this.position = position;
    }

    @Override
    public String getName() {
        return "Skeleton";
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void setPosition(Position position) {
        this.position = position;
    }

    public void moving() {
        int move = (int)(Math.random()*4);
        /*System.out.println(move);*/
        if (getPosition().getX() < 9 && getPosition().getX() > 0 && getPosition().getY() < 9 && getPosition().getY() > 0) {
            if (move == 0) {
                position = position.plus(Direction.UP.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen || tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.DOWN.asVector());
                        }
                    }
                }
            } else if (move == 1) {
                position = position.plus(Direction.LEFT.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen || tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.RIGHT.asVector());
                        }
                    }
                }
            } else if (move == 2){
                position = position.plus(Direction.RIGHT.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen || tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.LEFT.asVector());
                        }
                    }
                }
            } else {
                position = position.plus(Direction.DOWN.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen || tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.UP.asVector());
                        }
                    }
                }
            }
        }
    }
}
