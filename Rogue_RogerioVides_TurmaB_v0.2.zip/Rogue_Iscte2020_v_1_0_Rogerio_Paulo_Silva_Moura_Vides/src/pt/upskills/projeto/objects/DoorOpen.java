package pt.upskills.projeto.objects;

import pt.upskills.projeto.game.Engine;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Position;

import java.util.ArrayList;
import java.util.List;

public class DoorOpen implements ImageTile {


    /**
    public static void roomDoor(){
        doorPosition.add(new Position(5, 8));
    }*/

    private Position position;

    public DoorOpen(Position position) {
        this.position = position;
    }

    /*public Position getHeroPosition(){
        if (Engine.level == 0){
            return new Position(4,8);
        }else if (Engine.level == 1){
            return new Position(4,8);
        }
       return new Position(0,0);
    }*/


    @Override
    public String getName() {
        return "DoorOpen";
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void setPosition(Position position) {
        this.position = position;
    }
}