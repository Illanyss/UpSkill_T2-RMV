package pt.upskills.projeto.objects;

import pt.upskills.projeto.game.Engine;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.rogue.utils.Direction;
import pt.upskills.projeto.rogue.utils.Position;

public class Bat extends Enemy implements ImageTile {

    private Position position;
    private int move;

    public Bat(Position position) {
        super(position, 2);
        this.position = position;
    }

    @Override
    public String getName() {
        return "Bat";
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void setPosition(Position position) {
        this.position = position;
    }

    public void moving() {

        /*System.out.println(move);*/
        if (getPosition().getX() < 9 && getPosition().getX() > 0 && getPosition().getY() < 9 && getPosition().getY() > 0) {
            if (move == 0) {
                position = position.plus(Direction.LEFT.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.RIGHT.asVector());
                            move = 1;
                        }
                    }
                }
            } if (move == 1){
                position = position.plus(Direction.RIGHT.asVector());
                Hero hero;
                for (ImageTile tile : Engine.tiles) {
                    if (tile instanceof Hero) {
                        if (position.equals(tile.getPosition())) {
                            hero = ((Hero) tile);
                            hero.damage(1);
                        }
                    }
                    if (tile instanceof Obstacle || tile instanceof DoorOpen) {
                        if (position.equals(tile.getPosition())) {
                            position = position.plus(Direction.LEFT.asVector());
                            move = 0;
                        }
                    }
                }
            }

        }
    }
}
