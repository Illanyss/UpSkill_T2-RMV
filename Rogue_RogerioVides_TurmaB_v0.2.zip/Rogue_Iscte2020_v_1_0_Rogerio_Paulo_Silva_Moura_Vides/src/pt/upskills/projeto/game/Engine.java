package pt.upskills.projeto.game;

import pt.upskills.projeto.gui.ImageMatrixGUI;
import pt.upskills.projeto.gui.ImageTile;
import pt.upskills.projeto.objects.*;
import pt.upskills.projeto.rogue.utils.Position;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Engine {

    public static int level;
    public static int room = 0;
    public static Hero hero;
    public static List<Position> doorPosition = new ArrayList<>();
    public static List<ImageTile> tiles = new ArrayList<>();
    public static ImageMatrixGUI gui = ImageMatrixGUI.getInstance();
    //public static List<String> itemsInRoom = new ArrayList<>();

    public void init(){
        doorPosition.add(new Position(4, 1));
        doorPosition.add(new Position(4, 8));

        for(int i=0; i<10; i++){
            for(int j=0; j<10; j++){
                tiles.add(new Floor(new Position(i, j)));
            }
        }

        List<ImageTile> statusTiles = new ArrayList();
        for(int i = 0; i<10; i++){
            statusTiles.add(new BlackTile(new Position(i, 0)));
        }
        for(int i=3;i<7; i++){
            statusTiles.add(new GreenTile(new Position(i, 0)));
        }

        readMapFile(level);
        tiles.add(hero);

        gui.addObserver(hero);
        gui.newImages(tiles);
        gui.newStatusImages(statusTiles);
        gui.go();

        while (true){
            gui.update();
        }
    }

    public static void readMapFile(int level){

        try {
            Scanner fileScanner = new Scanner(new File("rooms/room"+level+".txt"));
            int i=0;
            while(fileScanner.hasNextLine()){
                String nextLine = fileScanner.nextLine();
                String[] separar = nextLine.split("");
                //etc...

                for(int j=0;j<separar.length;j++){
                    switch (separar[j]){

                        case "W":
                            tiles.add(new Wall(new Position(j, i)));
                            break;
                        case "0":
                            tiles.add(new DoorClosed(new Position(j, i)));
                            break;
                        case "1":
                            tiles.add(new DoorOpen(new Position(j, i)));
                            break;
                        case "S":
                            tiles.add(new Skeleton(new Position(j, i)));
                            break;
                        case "s":
                            tiles.add(new Sword(new Position(j, i)));
                            //itemsInRoom.add("Sword");
                            break;
                        case "k":
                            tiles.add(new Key(new Position(j, i)));
                            //itemsInRoom.add("Key");
                            break;
                        case "h":
                            if(hero == null) {
                                hero = new Hero(new Position(j, i));
                            }
                            break;
                        case "T":
                            tiles.add(new Thief(new Position(j, i)));
                            break;
                        case "B":
                            tiles.add(new Bat(new Position(j, i)));
                            break;

                    }
                }
                i++;
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Não foi possível ler o ficheiro");
        }
    }

    public static void RoomChange(){

        gui.clearImages();
        gui.clearStatus();
        tiles.clear();

        for(int i=0; i<10; i++){
            for(int j=0; j<10; j++){
                tiles.add(new Floor(new Position(i, j)));
            }
        }
        List<ImageTile> statusTiles = new ArrayList();
        for(int i = 0; i<10; i++){
            statusTiles.add(new BlackTile(new Position(i, 0)));
        }
        for(int i=3;i<7; i++){
            statusTiles.add(new GreenTile(new Position(i, 0)));
        }

        readMapFile(level);
        room = level;
        hero.setPosition(doorPosition.get(level));

        tiles.add(hero);
        gui.addObserver(hero);
        gui.newImages(tiles);
        gui.newStatusImages(statusTiles);
    }

    public static void main(String[] args){
        Engine engine = new Engine();
        engine.init();
    }
}
