package pt.upskill.projeto2.financemanager.date;

/**
 * @author upSkill 2020
 * <p>
 * ...
 */

public enum Month {
    NONE, JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
}
