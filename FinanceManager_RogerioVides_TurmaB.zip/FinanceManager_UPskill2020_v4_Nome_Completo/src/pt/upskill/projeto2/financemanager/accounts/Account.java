package pt.upskill.projeto2.financemanager.accounts;

import pt.upskill.projeto2.financemanager.categories.Category;
import pt.upskill.projeto2.financemanager.date.Date;
import pt.upskill.projeto2.financemanager.date.Month;
import pt.upskill.projeto2.financemanager.filters.AfterDateSelector;
import pt.upskill.projeto2.financemanager.filters.BeforeDateSelector;
import pt.upskill.projeto2.financemanager.filters.Filter;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Account{
    private String name;
    private long Id;
    private Date startDate;
    private Date endDate;
    private int interestRate;
    private List<StatementLine> statementLines = new ArrayList<>();
    private String additionalInfo = "";
    private double availableBalance = 0;

    public Account(long Id, String name){
        this.Id = Id;
        this.name = name;
    }

    public static Account newAccount(File file) {

        Account acc = null;
        String additionalInfo = "";
        int i=0;

        try {
            Scanner scanner = new Scanner(file);
            while(scanner.hasNext()) {
                if (i==0) {
                    scanner.nextLine();
                    i++;
                }
                if (i==1) {
                    try {
                        String[] line2 = scanner.nextLine().trim().split(";");
                        if (line2[4].trim().equals("SavingsAccount")){
                            acc = new SavingsAccount(Long.parseLong(line2[1].replaceAll("[^\\d.]", "")), line2[3].trim());
                        }else {
                            acc = new DraftAccount(Long.parseLong(line2[1].replaceAll("[^\\d.]", "")), line2[3].trim());
                        }
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        System.out.println("O formato não corresponde a um número!");
                    } i++;
                } else if (i == 2) {
                    String[] line3 = scanner.nextLine().trim().split("-");
                    Date startDate = new Date(Integer.parseInt(line3[0].replaceAll("[^\\d.]", "")), Integer.parseInt(line3[1].replaceAll("[^\\d.]", "")), Integer.parseInt(line3[2].replaceAll("[^\\d.]", "")));
                    if (acc != null) {
                        acc.setStartDate(startDate);
                        i++;
                    }
                } else if (i == 3) {
                    String[] line4 = scanner.nextLine().trim().split("-");
                    Date endDate = new Date(Integer.parseInt(line4[0].replaceAll("[^\\d.]", "")), Integer.parseInt(line4[1].replaceAll("[^\\d.]", "")), Integer.parseInt(line4[2].replaceAll("[^\\d.]", "")));
                    if (acc != null) {
                        acc.setEndDate(endDate);
                        i++;
                    }
                } else if (i == 4) {
                    scanner.nextLine();
                    i++;
                } else if (i > 4) {
                        String[] line;
                        line = scanner.nextLine().split(" ;");
                        String[] lined = line[0].split("-");
                        Date date = new Date(Integer.parseInt(lined[0]), Integer.parseInt(lined[1]), Integer.parseInt(lined[2].trim()));
                        String[] linee = line[1].split("-");
                        Date valueDate = new Date(Integer.parseInt(linee[0]), Integer.parseInt(linee[1]), Integer.parseInt(linee[2].trim()));
                        StatementLine statementLine = new StatementLine(date,
                                valueDate,
                                line[2].trim(),
                                Double.parseDouble(line[3].trim()),
                                Double.parseDouble(line[4].trim()),
                                Double.parseDouble(line[5].trim()),
                                Double.parseDouble(line[6].trim()),
                                null);
                        if (acc != null) {
                            acc.addStatementLine(statementLine);
                            acc.setAvailableBalance(Double.parseDouble(line[6]));
                        }
                    }
                }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ficheiro não encontrado!");
        } return acc;
    }

    public long getId() {
        return Id;
    }

    public String getName() {
        return name;
    }

    public String additionalInfo() {
        return additionalInfo;
    }

    private void setAvailableBalance(double availableBalance) {
        this.availableBalance = availableBalance;
    }

    public double getAvailableBalance() {
        return availableBalance;
    }

    public StatementLine getLastStatementLine() {
        if (statementLines.isEmpty()){
            return null;
        } return statementLines.get(statementLines.size()-1);
    }

    public List<StatementLine> getStatementLines() {
        return statementLines;
    }

    public double currentBalance() {
        if (statementLines.isEmpty()){
            return 0;
        }
        return getLastStatementLine().getAvailableBalance();
    }

    public double estimatedAverageBalance() {
        int currentYear = new Date().getYear();
        if (getLastStatementLine() != null){
            if(getLastStatementLine().getDate().getYear() < currentYear) {
                return currentBalance();
            }
        }

        Date lastYearsDate = new Date(31, 12, currentYear - 1);
        AfterDateSelector afterSelector = new AfterDateSelector(lastYearsDate);
        BeforeDateSelector beforeSelector = new BeforeDateSelector(lastYearsDate);
        Filter<StatementLine, AfterDateSelector> filterAfter = new Filter<>(afterSelector);
        Filter<StatementLine, BeforeDateSelector> filterBefore = new Filter<>(beforeSelector);
        List<StatementLine> yearStatements = (List<StatementLine>) filterAfter.apply(statementLines);
        List<StatementLine> lastYearStatements = (List<StatementLine>) filterBefore.apply(statementLines);
        if (statementLines.isEmpty()){
            return 0;
        }
        StatementLine lastStatement = lastYearStatements.get(lastYearStatements.size() - 1);
        double balancoTotal = 0.0;
        for(int i = 0; i < yearStatements.size();i++){
            StatementLine statement = yearStatements.get(i);
            int diffDays;
            if(i == 0){
                diffDays = statement.getDate().diffInDays(lastYearsDate);
            } else {
                diffDays = statement.getDate().diffInDays(lastStatement.getDate());
            }
            balancoTotal += lastStatement.getAvailableBalance() * diffDays;
            lastStatement = statement;
        }
        int numTotalDias = lastYearsDate.diffInDays(new Date()) -1;
        return balancoTotal / numTotalDias;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    private void setStartDate(Date startDate){
        this.startDate = startDate;
    }

    private void setEndDate(Date endDate){
        this.endDate = endDate;
    }

    public double getInterestRate() {
        return BanksConstants.normalInterestRate();
    }

    public void addStatementLine(StatementLine statementLine) {
        statementLines.add(statementLine);
        if (getStartDate() == null || getEndDate() == null){
            setStartDate(statementLine.getDate());
            setEndDate(statementLine.getDate());
        } else {
            if (getStartDate().after(statementLine.getDate())){
                setStartDate(statementLine.getDate());
            }
            if (getEndDate().before(statementLine.getDate())){
                setEndDate(statementLine.getDate());
            }
        }
    }

    public void removeStatementLinesBefore(Date date) {
        BeforeDateSelector selector = new BeforeDateSelector(date);
        Filter<StatementLine, BeforeDateSelector> filter = new Filter<>(selector);
        statementLines = filter.apply(statementLines);
    }

    public double totalDraftsForCategorySince(Category category, Date date) {
        double draftTotal = 0;
        if(statementLines.isEmpty()){
            draftTotal = 0;
        }
        AfterDateSelector selector = new AfterDateSelector(date);
        Filter<StatementLine, AfterDateSelector> filter = new Filter<>(selector);
        statementLines = filter.apply(statementLines);
        for (int i = 0; i < statementLines.size(); i++) {
            if (statementLines.get(i).getCategory() == category){
                draftTotal += statementLines.get(i).getDraft();
            }
        }
        return draftTotal;
    }

    public double totalForMonth(int mes, int ano) {
        double total = 0;
        for (StatementLine statementLine : statementLines){
            if (statementLine.getDate().getMonth()== Month.values()[mes] && statementLine.getDate().getYear()== ano)
            total += statementLine.getDraft();
        }
        return total;
    }

    public void autoCategorizeStatements(List<Category> categories) {

        for (StatementLine statementLine : statementLines) {
            for (Category category : categories) {
                if (category.hasTag(statementLine.getDescription())) {
                    statementLine.setCategory(category);
                }
            }

        }
    }

    public void setName(String other) {
        this.name = other;
    }
}
