package pt.upskill.projeto2.financemanager.accounts;

import pt.upskill.projeto2.financemanager.categories.Category;
import pt.upskill.projeto2.financemanager.date.Date;
import pt.upskill.projeto2.financemanager.exceptions.BadDate;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class StatementLine {
	private Date date;
	private Date valueDate;
	private String description;
	private double draft;
	private double credit;
	private double accountingBalance;
	private double availableBalance;
	private Category category;

	public StatementLine(Date date, Date valueDate, String description, double draft, double credit, double accountingBalance, double availableBalance, Category category) throws IllegalArgumentException{

		if (date == null){
			throw new IllegalArgumentException("Date can't be null");
		}
		this.date = date;
		if (valueDate == null){
			throw new IllegalArgumentException("Value Date can't be null");
		}
		this.valueDate = valueDate;
		if (description == null || description.equals("")){
			throw new IllegalArgumentException("A description must be present");
		}
		this.description = description;
		if (draft > 0){
			throw new IllegalArgumentException("Draft cannot be positive");
		}
		this.draft = draft;
		if (credit < 0){
			throw new IllegalArgumentException("Credit cannot be negative");
		}
		this.credit = credit;
		this.accountingBalance = accountingBalance;
		this.availableBalance = availableBalance;
		this.category = category;
	}

	public Date getDate() {
		return date;
	}

	public Date getValueDate() {
		return valueDate;
	}

	public String getDescription() {
		return description;
	}

	public double getDraft() {
		return draft;
	}

	public double getCredit() {
		return credit;
	}

	public double getAccountingBalance() {
		return accountingBalance;
	}

	public double getAvailableBalance() {
		return availableBalance;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category cat) {
		this.category = cat;
		
	}

}
