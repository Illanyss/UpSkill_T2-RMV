package pt.upskill.projeto2.financemanager.accounts.formats;

import pt.upskill.projeto2.financemanager.accounts.Account;
import pt.upskill.projeto2.financemanager.accounts.StatementLine;
import pt.upskill.projeto2.financemanager.date.Date;

public class FileAccountFormat implements Format<Account>{

    @Override
    public String format(Account account) {
        String nl = System.getProperty("line.separator");
        String content = "Account Info - " + new Date().toString() + nl
                + "Account  ;" + account.getId() + " ; EUR  ;" + account.getName() + " ;SavingsAccount ;" + nl
                + "Start Date ;" + account.getStartDate() + nl
                + "End Date ;" + account.getEndDate() + nl
                + "Date ;Value Date ;Description ;Draft ;Credit ;Accounting balance ;Available balance" + nl;
        for(StatementLine sl : account.getStatementLines()) {
            content = content + (sl.getDate() + " ;" + sl.getValueDate() + " ;" + sl.getDescription() + " ;" + sl.getDraft() + " ;" + sl.getCredit() + " ;" + sl.getAccountingBalance() + " ;" + sl.getAvailableBalance() + nl);
        }
        System.out.println(content);
        return content;
    }
}
