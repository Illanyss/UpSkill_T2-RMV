package pt.upskill.projeto2.financemanager.accounts.formats;

import pt.upskill.projeto2.financemanager.accounts.StatementLine;

/**
 * @author upSkill 2020
 * <p>
 * ...
 */
public interface StatementLineFormat extends Format<StatementLine> {

    String fields();

}
