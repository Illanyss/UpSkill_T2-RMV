package pt.upskill.projeto2.financemanager.accounts.formats;
/**
 * @author upSkill 2020
 * <p>
 * ...
 */
public interface Format<T> {
	String format(T objectToFormat);
}
