package pt.upskill.projeto2.financemanager.accounts;

import pt.upskill.projeto2.financemanager.categories.Category;

public class DraftAccount extends Account {

    public static Category draftCategory;

    public DraftAccount(long Id, String name) {
        super(Id, name);
    }

    @Override
    public double getInterestRate() {
        return BanksConstants.normalInterestRate();
    }
}