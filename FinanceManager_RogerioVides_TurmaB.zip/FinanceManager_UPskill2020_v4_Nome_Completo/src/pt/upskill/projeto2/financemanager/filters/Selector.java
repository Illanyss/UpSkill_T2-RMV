package pt.upskill.projeto2.financemanager.filters;

/**
 * @author POO 2014
 * <p>
 * ...
 */
public interface Selector<T> {
	boolean isSelected(T item);
}
