package pt.upskill.projeto2.financemanager.exceptions;

@SuppressWarnings("serial")
public class UnknownAccountException extends Exception {
    /**
     *
     * @author upSkill 2020
     *
     * ...
     *
     */

}

