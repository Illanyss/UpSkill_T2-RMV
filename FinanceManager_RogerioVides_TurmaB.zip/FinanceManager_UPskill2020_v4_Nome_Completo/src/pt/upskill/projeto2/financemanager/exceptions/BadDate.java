package pt.upskill.projeto2.financemanager.exceptions;


public class BadDate extends RuntimeException {

    /**
     * @author upSkill 2020
     * <p>
     * ...
     */

    private static final long serialVersionUID = -5979591749958758361L;


}
