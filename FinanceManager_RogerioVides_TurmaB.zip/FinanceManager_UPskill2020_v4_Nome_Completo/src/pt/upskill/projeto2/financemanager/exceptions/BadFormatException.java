package pt.upskill.projeto2.financemanager.exceptions;

@SuppressWarnings("serial")
public class BadFormatException extends Exception {
	/**
	 *
	 * @author upSkill 2020
	 *
	 * ...
	 *
	 */
	
}