package pt.upskill.projeto2.financemanager;

public class PersonalFinanceManager {
	// TODO

}
